//Jason Graves
//Professor Hunchuck
//3-22-2020
//Interface assinment
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.text.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;


public class Menu extends JFrame {
	private JButton time;
	private JButton calc;
	private JButton game;
	private JButton quit;
	
	public Menu() {
		super("Jason Graves 3/22/2020");
		setLayout(new FlowLayout());
		time = new JButton("Display the date and time");
		time.setPreferredSize(new Dimension(400, 200));
		time.setFont(new Font("Arial", Font.PLAIN, 32));
		add(time);
		calc = new JButton("Use the calculator");
		calc.setPreferredSize(new Dimension(400, 200));
		calc.setFont(new Font("Arial", Font.PLAIN, 38));
		add(calc);
		game = new JButton("Play the game");
		game.setPreferredSize(new Dimension(400, 200));
		game.setFont(new Font("Arial", Font.PLAIN, 55));
		add(game);
		quit = new JButton("Exit the program right now");
		quit.setFont(new Font("Arial", Font.PLAIN, 28));
		quit.setPreferredSize(new Dimension(400, 200));
		add(quit);
		
		SelectorClass select = new SelectorClass();
		time.addActionListener(select);
		calc.addActionListener(select);
		game.addActionListener(select);
		quit.addActionListener(select);
		
	}//end constructor
	
}//end class

		class SelectorClass implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			
			//make a variable here and use if statements to check what was picked
			String choice = e.getActionCommand();
			if (choice.contentEquals("Display the date and time")) {
				Date();
			}else if (choice.contentEquals("Use the calculator")){
				Calculator.createWindow();
				//code to call the calculator goes here
			}else if (choice.contentEquals("Play the game")){
				//code to call tic tac toe goes here
				new TicTacToe();
			}else if (choice.contentEquals("Exit the program right now")){
				System.exit(0);
			}
			
		}//end actionPreformed

		private void Date() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		JLabel message = new JLabel(dtf.format(now));
		message.setFont(new Font("Arial", Font.BOLD, 28));
		JOptionPane.showMessageDialog(null, message);
	
		}//end Date
		
	}//end class
		