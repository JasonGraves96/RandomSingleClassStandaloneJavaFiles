//Jason Graves
//Professor Hunchuck
//3-22-2020
//Interface assinment
import java.awt.*;
import javax.swing.*;


public class TestClass {

	public static void main(String[] args) {
		Menu a = new Menu();
		
		a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		a.setSize(900, 475);
		a.setVisible(true);
		
	}//end main

}//end TestClass