//Jason Graves
//Professor Hunchuck
//3-22-2020
//Interface assinment
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class TicTacToe extends JFrame {
	private Container pane;
	private String currentPlayer;
	private JButton [][] board;
	private boolean hasWinner;

	
	public TicTacToe() {
		super();
		pane = getContentPane();
		pane.setLayout(new GridLayout(3,3));
		setTitle("Tic Tac Toe");
		setSize(400, 400);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setVisible(true);
		currentPlayer = "x";
		board = new JButton[3][3];
		hasWinner = false;
		intialize();
				
	}//end constructor
	
	private void reset() {
		currentPlayer = "x";
		hasWinner = false;
		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {
				board[i][j].setText("");
			}
		}
	}//end reset
	private void intialize() {
		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {
				JButton btn = new JButton();
				btn.setFont(new Font("Aerial", Font.BOLD, 75));
				board[i][j] = btn;
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						if(((JButton)e.getSource()).getText().contentEquals("") && hasWinner == false) {
							btn.setText(currentPlayer);
							hasWinner();
							togglePlayer();
						}//end if
					}
				});
				pane.add(btn);
			}
			}
	}//end intialize
	private void togglePlayer() {
		if(currentPlayer.contentEquals("x"))
			currentPlayer = "o";
		else
			currentPlayer = "x";
		
	}//end togglePlayer
	private void hasWinner() {
		for(int i = 0; i < 3; ++i) {
            if(board[0][i].getText().equals(currentPlayer) && board[1][i].getText().equals(currentPlayer) && board[2][i].getText().equals(currentPlayer))  {
                JOptionPane.showMessageDialog(null, "player " + currentPlayer + " has won");
                hasWinner = true;
            }
            else if(board[i][0].getText().equals(currentPlayer) && board[i][1].getText().equals(currentPlayer) && board[i][2].getText().equals(currentPlayer))  {
            JOptionPane.showMessageDialog(null, "player " + currentPlayer + " has won");
            hasWinner = true;
            }
        }
        if (board[0][0].getText().equals(currentPlayer) && board[1][1].getText().equals(currentPlayer) && board[2][2].getText().equals(currentPlayer) ||
        (board[0][2].getText().equals(currentPlayer) && board[1][1].getText().equals(currentPlayer) && board[2][0].getText().equals(currentPlayer))) {
        JOptionPane.showMessageDialog(null, "player " + currentPlayer + " has won");
        hasWinner = true;
        }
	}//end hasWinner
	
}//end class
